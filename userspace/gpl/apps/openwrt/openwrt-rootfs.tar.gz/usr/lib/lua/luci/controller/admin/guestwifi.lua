module("luci.controller.admin.guestwifi", package.seeall)

function index()
	entry({"admin", "management", "guestwifi"}, call("guestWifi_cfg"), _("Guest Wifi"), 11)
end


function guestWifi_cfg()
	local wl_bss_enabled = luci.http.formvalue("wl_bss_enabled")
	
	--Check if http get or post
	if wl_bss_enabled then
		local wl_ssid = luci.http.formvalue("wl_ssid")
		local wl_closed = luci.http.formvalue("wl_closed")
		local wl_ap_isolate = luci.http.formvalue("wl_ap_isolate")
		local wl_bss_maxassoc = luci.http.formvalue("wl_bss_maxassoc")
		local wl_wme_bss_disable = luci.http.formvalue("wl_wme_bss_disable")
		local wl_wmf_bss_enable = luci.http.formvalue("wl_wmf_bss_enable")
		local wl_dwds = luci.http.formvalue("wl_dwds")
		local wl_bss_opmode_cap_reqd = luci.http.formvalue("wl_bss_opmode_cap_reqd")
		local wl_auth = luci.http.formvalue("wl_auth")
		local wl_auth_mode = luci.http.formvalue("wl_auth_mode")
		local wl_osenen = luci.http.formvalue("wl_osenen")
		local wl_akm_wpa = luci.http.formvalue("wl_akm_wpa")
		local wl_akm_psk = luci.http.formvalue("wl_akm_psk")
		local wl_akm_wpa2 = luci.http.formvalue("wl_akm_wpa2")
		local wl_akm_psk2 = luci.http.formvalue("wl_akm_psk2")
		local wl_akm_psk2_ft = luci.http.formvalue("wl_akm_psk2_ft")
		local wl_akm_brcm_psk = luci.http.formvalue("wl_akm_brcm_psk")
		local wl_preauth = luci.http.formvalue("wl_preauth")
		local wl_wep = luci.http.formvalue("wl_wep")
		local wl_crypto = luci.http.formvalue("wl_crypto")
		local wl_radius_ipaddr = luci.http.formvalue("wl_radius_ipaddr")
		local wl_radius_port = luci.http.formvalue("wl_radius_port")
		local wl_radius_key = luci.http.formvalue("wl_radius_key")
		local wl_wpa_psk = luci.http.formvalue("wl_wpa_psk")
		local wl_key1 = luci.http.formvalue("wl_key1")
		local wl_key2 = luci.http.formvalue("wl_key2")
		local wl_key3 = luci.http.formvalue("wl_key3")
		local wl_key4 = luci.http.formvalue("wl_key4")
		local wl_key = luci.http.formvalue("wl_key")
		local wl_mfp = luci.http.formvalue("wl_mfp")
		local wl_wpa_gtk_rekey = luci.http.formvalue("wl_wpa_gtk_rekey")
		local wl_net_reauth = luci.http.formvalue("wl_net_reauth")
		local dbus = require "dbus"
		local akmPara
		local commonPara = "dict:string:string:wl_unit,0,wl_bssid,1"..
							",wl_bss_enabled,"..wl_bss_enabled..",wl_ssid,"..wl_ssid..",wl_closed,"..wl_closed..
 							",wl_ap_isolate,"..wl_ap_isolate..",wl_bss_maxassoc,"..wl_bss_maxassoc..",wl_wme_bss_disable,"..wl_wme_bss_disable..
 							",wl_wmf_bss_enable,"..wl_wmf_bss_enable..",wl_dwds,"..wl_dwds..",wl_bss_opmode_cap_reqd,"..wl_bss_opmode_cap_reqd

		if wl_wep == "disabled" then
			akmPara =",wl_akm,".." "..",wl_preauth,"..wl_preauth..",wl_akm_wpa,"..wl_akm_wpa..",wl_akm_psk,"..wl_akm_psk..
					",wl_akm_wpa2,"..wl_akm_wpa2..",wl_akm_psk2,"..wl_akm_psk2..",wl_akm_brcm_psk,"..wl_akm_brcm_psk..
					",wl_wpa_psk,"..wl_wpa_psk..",wl_crypto,"..wl_crypto..",wl_wpa_gtk_rekey,"..wl_wpa_gtk_rekey..
					",wl_mfp,"..wl_mfp..",wl_net_reauth,"..wl_net_reauth
		else
			akmPara = ",wl_wep,"..wl_wep..",wl_key1,"..wl_key1..",wl_key2,"..wl_key2..",wl_key3,"..wl_key3..",wl_key4,"..wl_key4..",wl_key,"..wl_key..
 					",wl_radius_ipaddr,"..wl_radius_ipaddr..",wl_radius_port,"..wl_radius_port..",wl_radius_key,"..wl_radius_key
					
		end
		
		--guestWifiCallPara length should be < ?512, or there's buffer overflow in dbus.c
		local guestWifiCallPara = commonPara..akmPara
		
		guestWifiCall = dbus.sysCall("com.broadcom.DataAdaptation", "/com/broadcom/DataAdaptation", 
							"com.broadcom.DataAdaptation.Wifi", "SetWifiConfigration", {guestWifiCallPara})
							
		if guestWifiCall[1] ~= 0 then
			luci.template.render("error500", {
				message = luci.i18n.translate(guestWifiCall[2]),
			})
			return
		else
			if  guestWifiCall[4] ~= 0 then
				luci.template.render("error500", {
					message = luci.i18n.translate(guestWifiCall[3]),
				})
				return
			end
		end		
	end		
	
	luci.template.render("admin_management/guestwifi")
end

